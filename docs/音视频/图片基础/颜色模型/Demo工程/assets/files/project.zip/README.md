# 颜色模型Demo

## 环境配置

```shell
$ conda create -n color-model python=3.9
$ conda activate color-model
$ pip install -r requirements.txt
```

## 示例代码

* [rgb.py](rgb.py)
* [hsv.py](hsv.py)
* [Lab](Lab.py)
